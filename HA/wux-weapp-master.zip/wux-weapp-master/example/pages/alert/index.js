import ad from '../index/ad'

ad({})
